# ImageRepresentationUseType

Enumerate use types of ImageRepresentations

## Enum

* `UPLOADED_BY_SUBMITTER` (value: `'UPLOADED_BY_SUBMITTER'`)

* `STATIC_DISPLAY` (value: `'STATIC_DISPLAY'`)

* `THUMBNAIL` (value: `'THUMBNAIL'`)

* `INTERACTIVE_DISPLAY` (value: `'INTERACTIVE_DISPLAY'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


