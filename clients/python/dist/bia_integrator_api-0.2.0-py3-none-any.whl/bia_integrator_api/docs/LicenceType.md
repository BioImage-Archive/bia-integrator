# LicenceType


## Enum

* `CC0` (value: `'CC0'`)

* `CC_BY_4_DOT_0` (value: `'CC_BY_4.0'`)

* `CC_BY_MINUS_SA_3_DOT_0` (value: `'CC_BY-SA_3.0'`)

* `CC_BY_MINUS_NC_MINUS_SA_3_DOT_0` (value: `'CC_BY-NC-SA_3.0'`)

* `CC_BY_MINUS_NC_MINUS_ND_4_DOT_0` (value: `'CC_BY-NC-ND_4.0'`)

* `CC_BY_MINUS_SA_2_DOT_1_JP` (value: `'CC_BY-SA_2.1_JP'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


