# AnnotationType


## Enum

* `CLASS_LABELS` (value: `'class_labels'`)

* `BOUNDING_BOXES` (value: `'bounding_boxes'`)

* `COUNTS` (value: `'counts'`)

* `DERIVED_ANNOTATIONS` (value: `'derived_annotations'`)

* `GEOMETRICAL_ANNOTATIONS` (value: `'geometrical_annotations'`)

* `GRAPHS` (value: `'graphs'`)

* `POINT_ANNOTATIONS` (value: `'point_annotations'`)

* `SEGMENTATION_MASK` (value: `'segmentation_mask'`)

* `TRACKS` (value: `'tracks'`)

* `WEAK_ANNOTATIONS` (value: `'weak_annotations'`)

* `OTHER` (value: `'other'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


